.NET Framework 4.7.2

1. Install .NET Framework 4.7.2
2. Unzip project
3. Execute The Clicker Game.exe